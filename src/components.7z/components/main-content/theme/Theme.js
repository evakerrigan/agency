const dataThems = [
  { theme : "SOFA", img : "../../assets/image/sofa.jpg", type : "Design"},
  { theme : "KeyBoard", img : "../../assets/image/keyboard.jpg", type : "Branding"},
  { theme : "Work Media", img : "../../assets/image/work-media.jpg", type : "Illustration"},
  { theme : "DDDone", img : "../../assets/image/dddone.jpg", type : "Motion"},
  { theme : "Abstract", img : "../../assets/image/abstract.jpg", type : "Design"},
  { theme : "HandP", img : "../../assets/image/handp.jpg", type : "Branding"},
  { theme : "Architect", img : "../../assets/image/architect.jpg", type : "Motion"},
  { theme : "Calc", img : "../../assets/image/calc.jpg", type : "Design"},
  { theme : "Sport", img : "../../assets/image/sport.jpg", type : "Branding"}
]


const Theme = () => {

  /*let notes = [];

  notes = dataThems;
  const themeList = document.getElementById("themelist");
 
  notes.forEach((element) => {
    themeList.innerHTML += `
      <li class="portfolio-theme-item">
      ${element.theme}
      <img class="" src={require(${element.img})} alt="logo ${element.theme}">
      </li>      
      `;
  });


*/


  return (

    <img src={require(`${dataThems[1].img}`)} alt=""></img>

    )
  }
  
  export default Theme